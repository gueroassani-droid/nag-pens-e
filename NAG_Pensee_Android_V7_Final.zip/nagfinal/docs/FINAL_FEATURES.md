# NAG Pensée — Synthèse finale

## 1. Identité
- NAG Pensée
- Black / white / gold editorial identity
- Ink / engraving illustrations
- Signature “— Guero”
- Intro animation ~3 seconds

## 2. Languages
French, English, Spanish, Portuguese, Chinese, Lingala, Swahili. Choice is persisted locally and can later be changed in settings.

## 3. Personal archive
Create, edit, delete, search, categorize, tag and favorite thoughts. Local storage remains encrypted.

## 4. Privacy
PIN, biometric/device credential, automatic lock, offline-first operation, no automatic public publishing, explicit sharing.

## 5. Cloud
Optional private synchronization client with encrypted local credentials, explicit enablement, configurable endpoint and last-sync status. Production requires deployment of the NAG backend.

## 6. Voice
Read-aloud is online-only. The selected text and language code are sent to a cloud TTS service only when the user presses Listen. Lingala/Swahili quality must be verified with the chosen provider.

## 7. Sharing
Sharing is per-thought and explicit. The archive itself is never exposed by default. Production share links/permissions require the NAG backend.

## 8. AI
AI is optional and consent-based. Planned operations: summarize, classify, connect related thoughts. Before sending data, the UI should identify what will leave the device and to which service.

## 9. Account & devices
Product surface is prepared for private account creation, recovery and device revocation. Backend implementation remains required for production.

## 10. Production checklist
- Deploy authentication/backend
- Use end-to-end/envelope encryption for cloud data
- Add real TTS provider and verify all 7 languages
- Add AI provider with explicit consent and data minimization
- Implement account recovery without weakening encryption guarantees
- Implement signed release APK/AAB and Play distribution
- Complete security review / penetration testing
