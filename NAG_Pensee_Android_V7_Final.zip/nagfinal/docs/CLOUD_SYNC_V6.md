# NAG Pensée V6 — Cloud privé

La V6 prépare une synchronisation privée entre l'application et un serveur contrôlé par le propriétaire du service.

## Principe
- Les pensées restent disponibles hors ligne.
- La synchronisation est désactivée par défaut.
- L'accès cloud utilise un jeton stocké dans le stockage chiffré Android.
- Le client envoie uniquement les pensées au point `/v1/thoughts/sync` lorsque l'utilisateur demande une synchronisation.
- Aucune pensée n'est publiée automatiquement.

## Contrat serveur
`POST /v1/thoughts/sync`

Headers:
- `Authorization: Bearer <token>`
- `Content-Type: application/json`

Body:
```json
{
  "deviceId": "device-id",
  "thoughts": [
    {"id":"...","text":"...","category":"Philosophie","tags":"...","timestamp":0}
  ]
}
```

Réponse `2xx` : synchronisation acceptée.

## Prochaine couche serveur
Le serveur de production devra ajouter : authentification de compte, chiffrement côté serveur, versionnement/conflits, suppression répliquée, révocation de session, sauvegardes et journal d'audit minimal.
