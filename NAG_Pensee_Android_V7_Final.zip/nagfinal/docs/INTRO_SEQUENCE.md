# NAG Pensée — ouverture cinématique

## Séquence
1. Écran noir.
2. Le symbole Thought Archive se dessine progressivement en doré.
3. Le mot **NAG** apparaît.
4. **PENSÉE** apparaît juste dessous.
5. Signature : « Une pensée, une trace. »
6. Durée cible : environ 3 secondes.
7. Transition directe vers le choix de langue lors du premier lancement.

## Principe
L'animation est volontairement courte et élégante, inspirée du rôle d'une identité de lancement comme Netflix, mais avec une identité propre à NAG Pensée.

## Important
Ce n'est pas une vidéo lourde chargée depuis Internet. L'animation est rendue localement dans l'application afin de :
- démarrer immédiatement ;
- fonctionner hors ligne ;
- ne pas ajouter un fichier vidéo inutilement lourd ;
- conserver une animation nette sur différentes tailles d'écran.

## Suite
Quand le logo définitif sera validé, le symbole temporaire de l'animation sera remplacé par le véritable logo Thought Archive + monogramme doré.
