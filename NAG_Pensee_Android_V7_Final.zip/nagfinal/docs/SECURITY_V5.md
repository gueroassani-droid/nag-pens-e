# NAG Pensée V5 — sécurité

- Premier lancement : création d'un PIN de 4 à 6 chiffres.
- Le PIN est stocké sous forme de hachage SHA-256 dans `EncryptedSharedPreferences`, lui-même protégé par Android Keystore.
- Déverrouillage par biométrie ou identifiant du téléphone lorsque le système le permet.
- Verrouillage automatique lorsque l'application quitte le premier plan.
- Les pensées restent chiffrées localement via `EncryptedSharedPreferences` dans cette version prototype.
- La préférence de langue et l'état de l'introduction sont également persistés.
- La synchronisation cloud reste optionnelle et n'est pas activée automatiquement.

## Production

Pour une version publiée à grande échelle, migrer les pensées vers une base Room chiffrée (SQLCipher ou équivalent), utiliser un KDF adapté au PIN avec sel unique (Argon2id/scrypt/PBKDF2 selon la pile retenue), ajouter un mécanisme de récupération sécurisé et durcir la gestion du verrouillage/anti-bruteforce.
