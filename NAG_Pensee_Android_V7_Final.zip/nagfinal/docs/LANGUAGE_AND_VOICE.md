# Langues et lecture vocale — V3

## Langues initiales
1. Français — fr
2. English — en
3. Español — es
4. Português — pt
5. 中文 — zh
6. Lingála — ln
7. Kiswahili — sw

The language picker appears before the home screen on first launch. The choice is persisted and can be changed later in Settings.

## Global reach
The seven languages are the initial release set. Country detection can later be used only as a suggestion; it must never override the user's chosen language. Additional languages can be added without changing the data model.

## Online-only text-to-speech
The read-aloud control is deliberately cloud-based:
- require an internet connection
- send only the selected text and selected language to the voice provider
- receive/play generated audio
- do not silently use Android offline TTS
- show a clear "Lecture en ligne uniquement" label

### Important language caveat
Cloud TTS availability and voice quality are provider-dependent. French, English, Spanish, Portuguese and Chinese have broad commercial support. Lingala and Swahili must be verified against the chosen TTS provider before promising production-quality voices. If a provider does not support a requested language, the app should clearly report that limitation rather than substitute another language without consent.

## Privacy
For private thoughts, cloud TTS is an explicit data transmission. The user should confirm/enable "Lecture en ligne" in privacy settings, and the UI should explain that the selected text is sent to the voice service for synthesis.
