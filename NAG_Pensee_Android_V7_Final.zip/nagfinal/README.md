# NAG Pensée — V7 Final Product Build

NAG Pensée is a private, offline-first thought archive with an editorial black/white/gold identity and the personal signature “— Guero”.

## Launch
Intro animation (~3s) → language selection (7 languages) → PIN setup → private archive.

## Included product surface
- Offline encrypted personal thought archive
- Create, edit, delete and search thoughts
- Categories and editorial ink illustrations
- Favorites
- Explicit per-thought sharing state (never public by default)
- PIN + biometric/device-credential unlock where supported
- Automatic lock when the app leaves the foreground
- Remembered language preference
- 7 initial languages: Français, English, Español, Português, 中文, Lingála, Kiswahili
- Online-only text-to-speech contract with language code passed explicitly
- Optional private-cloud synchronization client
- Last-sync status and configurable endpoint/token
- Account/device-management product surface prepared for the backend
- AI feature surface prepared as explicit opt-in; no thought is sent to an AI service by default
- Privacy/security documentation and cloud API contracts

## Important production boundary
The Android client is packaged as source. A real NAG cloud backend, authentication service, TTS provider, AI provider and production signing pipeline still have to be deployed and connected. The client does not pretend those services exist locally.

## Identity
NAG Pensée — “Une pensée, une trace.”
Signature: “— Guero”
