package com.nagpensee.app

enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val countryHint: String
) {
    FRENCH("fr", "Français", "French", "Francophonie"),
    ENGLISH("en", "English", "English", "Monde"),
    SPANISH("es", "Español", "Spanish", "Amérique latine, Espagne"),
    PORTUGUESE("pt", "Português", "Portuguese", "Brésil, Portugal"),
    CHINESE("zh", "中文", "Chinese", "Chine et communautés sinophones"),
    LINGALA("ln", "Lingála", "Lingala", "RDC et Congo"),
    SWAHILI("sw", "Kiswahili", "Swahili", "Afrique de l'Est et RDC")
}

object LanguagePrefs {
    const val PREFS = "nag_language"
    const val KEY = "selected_language"
}
