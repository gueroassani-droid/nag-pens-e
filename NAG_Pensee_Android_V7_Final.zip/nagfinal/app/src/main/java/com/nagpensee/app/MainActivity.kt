package com.nagpensee.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val PREFS = "nag_secure_store"
private const val KEY_PIN_HASH = "pin_hash"
private const val KEY_LANGUAGE = "language"
private const val KEY_INTRO = "intro_done"
private const val KEY_SYNC_ENABLED = "sync_enabled"
private const val KEY_SYNC_ENDPOINT = "sync_endpoint"
private const val KEY_SYNC_TOKEN = "sync_token"
private const val KEY_LAST_SYNC = "last_sync"

data class Thought(val id:String=UUID.randomUUID().toString(), val text:String,
                   val category:String, val tags:String="", val timestamp:Long=System.currentTimeMillis(),
                   val favorite:Boolean=false, val shared:Boolean=false)

private val cats=listOf("Philosophie","Vie quotidienne","Vie sociale","Histoire","Relations / sentiments","Idées","Science / technologie","Autres")
private val ink=Color(0xFFEDE9DF); private val gold=Color(0xFFD7A94A); private val dark=Color(0xFF090A0C)
private val panel=Color(0xFF111317); private val muted=Color(0xFFA7A29A)

private val labels = mapOf(
 "fr" to mapOf("home" to "Accueil","new" to "Nouvelle pensée","search" to "Rechercher une pensée…","categories" to "Catégories","recent" to "Pensées récentes","profile" to "Mon espace","save" to "Enregistrer","cancel" to "Annuler","read" to "Écouter"),
 "en" to mapOf("home" to "Home","new" to "New thought","search" to "Search a thought…","categories" to "Categories","recent" to "Recent thoughts","profile" to "My space","save" to "Save","cancel" to "Cancel","read" to "Listen"),
 "es" to mapOf("home" to "Inicio","new" to "Nueva reflexión","search" to "Buscar una reflexión…","categories" to "Categorías","recent" to "Reflexiones recientes","profile" to "Mi espacio","save" to "Guardar","cancel" to "Cancelar","read" to "Escuchar"),
 "pt" to mapOf("home" to "Início","new" to "Nova reflexão","search" to "Pesquisar uma reflexão…","categories" to "Categorias","recent" to "Reflexões recentes","profile" to "Meu espaço","save" to "Guardar","cancel" to "Cancelar","read" to "Ouvir"),
 "zh" to mapOf("home" to "首页","new" to "新想法","search" to "搜索想法…","categories" to "分类","recent" to "最近的想法","profile" to "我的空间","save" to "保存","cancel" to "取消","read" to "朗读"),
 "ln" to mapOf("home" to "Libanda","new" to "Likanisi ya sika","search" to "Luka likanisi…","categories" to "Biteni","recent" to "Bikanisi ya sika","profile" to "Esika na ngai","save" to "Bomba","cancel" to "Longola","read" to "Yoka"),
 "sw" to mapOf("home" to "Mwanzo","new" to "Wazo jipya","search" to "Tafuta wazo…","categories" to "Makundi","recent" to "Mawazo ya hivi karibuni","profile" to "Nafasi yangu","save" to "Hifadhi","cancel" to "Ghairi","read" to "Sikiliza")
)

class SecurePrefs(private val a:Context){
    private val p by lazy{EncryptedSharedPreferences.create(PREFS,MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),a,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)}
    fun pinConfigured()=p.contains(KEY_PIN_HASH)
    fun setPin(pin:String){p.edit().putString(KEY_PIN_HASH,hash(pin)).apply()}
    fun checkPin(pin:String)=p.getString(KEY_PIN_HASH,null)==hash(pin)
    fun language():String?=p.getString(KEY_LANGUAGE,null)
    fun setLanguage(code:String){p.edit().putString(KEY_LANGUAGE,code).apply()}
    fun introDone()=p.getBoolean(KEY_INTRO,false)
    fun setIntroDone(){p.edit().putBoolean(KEY_INTRO,true).apply()}
    fun syncEnabled()=p.getBoolean(KEY_SYNC_ENABLED,false)
    fun setSyncEnabled(v:Boolean){p.edit().putBoolean(KEY_SYNC_ENABLED,v).apply()}
    fun syncEndpoint()=p.getString(KEY_SYNC_ENDPOINT,"https://sync.nagpensee.app/v1") ?: "https://sync.nagpensee.app/v1"
    fun setSyncEndpoint(v:String){p.edit().putString(KEY_SYNC_ENDPOINT,v.trimEnd('/')).apply()}
    fun syncToken()=p.getString(KEY_SYNC_TOKEN,null)
    fun setSyncToken(v:String){p.edit().putString(KEY_SYNC_TOKEN,v).apply()}
    fun lastSync()=p.getLong(KEY_LAST_SYNC,0L)
    fun setLastSync(v:Long){p.edit().putLong(KEY_LAST_SYNC,v).apply()}
    private fun hash(s:String):String=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}

class ThoughtStore(private val a:ComponentActivity){
    private val p by lazy{EncryptedSharedPreferences.create(PREFS,MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),a,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)}
    fun load():List<Thought> = runCatching{val x=JSONArray(p.getString("thoughts","[]"));(0 until x.length()).map{val o=x.getJSONObject(it);Thought(o.getString("id"),o.getString("text"),o.getString("category"),o.optString("tags"),o.getLong("timestamp"),o.optBoolean("favorite",false),o.optBoolean("shared",false))}}.getOrDefault(emptyList())
    fun save(v:List<Thought>){val x=JSONArray();v.forEach{t->x.put(JSONObject().apply{put("id",t.id);put("text",t.text);put("category",t.category);put("tags",t.tags);put("timestamp",t.timestamp);put("favorite",t.favorite);put("shared",t.shared)})};p.edit().putString("thoughts",x.toString()).apply()}
}

data class SyncResult(val ok:Boolean,val message:String)

object PrivateSyncService {
    suspend fun sync(thoughts:List<Thought>, prefs:SecurePrefs):SyncResult = withContext(Dispatchers.IO) {
        if(!prefs.syncEnabled()) return@withContext SyncResult(false,"Synchronisation désactivée")
        val token=prefs.syncToken() ?: return@withContext SyncResult(false,"Compte cloud non configuré")
        runCatching {
            val c=(URL(prefs.syncEndpoint()+"/thoughts/sync").openConnection() as HttpURLConnection).apply {
                requestMethod="POST"; connectTimeout=10000; readTimeout=15000; doOutput=true
                setRequestProperty("Authorization","Bearer $token"); setRequestProperty("Content-Type","application/json")
            }
            val payload=JSONObject().apply {
                put("deviceId",android.os.Build.MODEL+":"+android.os.Build.ID)
                put("thoughts",JSONArray().apply{thoughts.forEach{t->put(JSONObject().apply{put("id",t.id);put("text",t.text);put("category",t.category);put("tags",t.tags);put("timestamp",t.timestamp);put("favorite",t.favorite);put("shared",t.shared)})}})
            }.toString()
            c.outputStream.use{it.write(payload.toByteArray())}; val code=c.responseCode; c.disconnect()
            if(code in 200..299){prefs.setLastSync(System.currentTimeMillis());SyncResult(true,"Synchronisation terminée")}else SyncResult(false,"Serveur indisponible ($code)")
        }.getOrElse{SyncResult(false,"Connexion impossible")}
    }
}

class MainActivity:ComponentActivity(){
    private lateinit var secure:SecurePrefs
    private var appLocked=true
    override fun onCreate(b:Bundle?){super.onCreate(b);secure=SecurePrefs(this);setContent{NagApp(ThoughtStore(this),secure,{appLocked},{appLocked=false})}}
    override fun onStop(){super.onStop();if(secure.pinConfigured())appLocked=true}
    fun unlockBiometric(onResult:(Boolean)->Unit){
        val manager=BiometricManager.from(this)
        if(manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)!=BiometricManager.BIOMETRIC_SUCCESS){onResult(false);return}
        val prompt=BiometricPrompt(this,mainExecutor,object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){onResult(true)}})
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("Déverrouiller NAG Pensée").setSubtitle("Accéder à votre archive personnelle").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        prompt.authenticate(info)
    }
}

@Composable fun Illustration(modifier:Modifier=Modifier){Canvas(modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF202124))){val w=size.width;val h=size.height;drawLine(ink,androidx.compose.ui.geometry.Offset(0f,h*.72f),androidx.compose.ui.geometry.Offset(w,h*.72f),4f);drawArc(ink,0f,180f,false,Stroke(3f),androidx.compose.ui.geometry.Offset(w*.08f,h*.12f),androidx.compose.ui.geometry.Size(w*.84f,h*.55f));drawCircle(ink,androidx.compose.ui.geometry.Offset(w*.53f,h*.36f),w*.12f,style=Stroke(3f));drawLine(ink,androidx.compose.ui.geometry.Offset(w*.53f,h*.48f),androidx.compose.ui.geometry.Offset(w*.46f,h*.68f),3f);drawLine(ink,androidx.compose.ui.geometry.Offset(w*.46f,h*.68f),androidx.compose.ui.geometry.Offset(w*.28f,h*.73f),3f);drawLine(ink,androidx.compose.ui.geometry.Offset(w*.46f,h*.68f),androidx.compose.ui.geometry.Offset(w*.69f,h*.72f),3f)}}

@Composable fun NagIntro(onFinished:()->Unit){var visible by remember{mutableStateOf(true)};val progress=remember{Animatable(0f)};LaunchedEffect(Unit){progress.animateTo(1f,tween(2700,easing=FastOutSlowInEasing));kotlinx.coroutines.delay(300);visible=false;onFinished()};if(visible){val p=progress.value;Box(Modifier.fillMaxSize().background(dark),contentAlignment=Alignment.Center){Canvas(Modifier.fillMaxSize()){val cx=size.width/2f;val cy=size.height/2f;val r=size.minDimension*.17f;drawArc(gold,-82f,300f*p,false,Stroke(5f));drawCircle(gold,r*(.15f+.85f*p),androidx.compose.ui.geometry.Offset(cx,cy),style=Stroke(2.5f));drawLine(gold,androidx.compose.ui.geometry.Offset(cx-r*.9f,cy+r*.9f),androidx.compose.ui.geometry.Offset(cx+r*.9f,cy+r*.9f),2.5f)};Column(horizontalAlignment=Alignment.CenterHorizontally){Text("NAG",color=gold,style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold);Text("PENSÉE",color=ink,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(10.dp));Text("Une pensée, une trace.",color=muted,style=MaterialTheme.typography.labelMedium);Text("— Guero",color=gold,style=MaterialTheme.typography.labelSmall)}}}}

@Composable fun NagApp(store:ThoughtStore,secure:SecurePrefs,isLocked:()->Boolean,unlock:()->Unit){
    var introDone by remember{mutableStateOf(secure.introDone())};var lang by remember{mutableStateOf(secure.language()?.let{c->AppLanguage.values().firstOrNull{it.code==c}})}
    if(!introDone){NagIntro{secure.setIntroDone();introDone=true};return}
    if(!secure.pinConfigured()){PinSetup(secure);return}
    if(isLocked()){UnlockScreen(secure,unlock);return}
    val selectedLang=lang?:return LanguageScreen{secure.setLanguage(it.code);lang=it}
    var list by remember{mutableStateOf(store.load())};var tab by remember{mutableStateOf(0)};var selected by remember{mutableStateOf<Thought?>(null)};var show by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<Thought?>(null)};val l=selectedLang
    MaterialTheme(colorScheme=darkScheme){Scaffold(containerColor=dark,bottomBar={NavigationBar(containerColor=panel){val nav=listOf(labels[l.code]!!["home"]!!,labels[l.code]!!["categories"]!!,"⌕","☆",labels[l.code]!!["profile"]!!);nav.forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","▦","⌕","☆","○")[i])},label={Text(s)})}},floatingActionButton={FloatingActionButton(containerColor=gold,contentColor=dark,onClick={editing=null;show=true}){Text("+")}}){pad->when(tab){0->Home(list,l,onNew={editing=null;show=true},onOpen={selected=it});1->Categories(list,l,onOpen={selected=it});2->Search(list,l,onOpen={selected=it});3->Favorites(list,l,onOpen={selected=it});else->Profile(l,secure,list)}}}
    selected?.let{t->Detail(t,l,onBack={selected=null},onEdit={editing=t;selected=null;show=true},onDelete={list=list.filterNot{it.id==t.id};store.save(list);selected=null},onFavorite={list=list.map{x->if(x.id==t.id)x.copy(favorite=!x.favorite)else x};store.save(list);selected=list.firstOrNull{x->x.id==t.id}},onShare={list=list.map{x->if(x.id==t.id)x.copy(shared=true)else x};store.save(list);selected=list.firstOrNull{x->x.id==t.id}})}
    if(show)Editor(editing,l,onDismiss={show=false},onSave={txt,cat,tags->list=if(editing==null)list+Thought(text=txt,category=cat,tags=tags)else list.map{if(it.id==editing!!.id)editing!!.copy(text=txt,category=cat,tags=tags,timestamp=System.currentTimeMillis())else it};store.save(list);show=false})
}

@Composable fun PinSetup(secure:SecurePrefs){var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().background(dark).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("NAG PENSÉE",color=gold,style=MaterialTheme.typography.headlineMedium);Text("— Guero",color=gold,style=MaterialTheme.typography.labelSmall);Spacer(Modifier.height(28.dp));Text("Créer votre code PIN",color=ink,style=MaterialTheme.typography.headlineSmall);Text("Ce code protège l’accès à votre archive.",color=muted);Spacer(Modifier.height(18.dp));OutlinedTextField(pin,{if(it.length<=6)pin=it.filter(Char::isDigit)},label={Text("PIN (4 à 6 chiffres)")});OutlinedTextField(confirm,{if(it.length<=6)confirm=it.filter(Char::isDigit)},label={Text("Confirmer le PIN")});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(14.dp));Button(onClick={if(pin.length<4)error="Le PIN doit contenir 4 à 6 chiffres." else if(pin!=confirm)error="Les deux PIN ne correspondent pas." else secure.setPin(pin)},colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark)){Text("Protéger NAG Pensée")}}}

@Composable fun UnlockScreen(secure:SecurePrefs,unlock:()->Unit){var pin by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};val activity=LocalContext.current as? MainActivity;Column(Modifier.fillMaxSize().background(dark).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("NAG PENSÉE",color=gold,style=MaterialTheme.typography.headlineMedium);Text("— Guero",color=gold,style=MaterialTheme.typography.labelSmall);Spacer(Modifier.height(24.dp));Text("Archive verrouillée",color=ink,style=MaterialTheme.typography.headlineSmall);OutlinedTextField(pin,{if(it.length<=6)pin=it.filter(Char::isDigit)},label={Text("PIN")});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(12.dp));Button(onClick={if(secure.checkPin(pin))unlock() else{error="PIN incorrect.";pin=""}},colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark)){Text("Déverrouiller")};if(activity!=null){TextButton(onClick={activity.unlockBiometric{if(it)unlock()}}){Text("Empreinte / verrouillage du téléphone",color=gold)}}}}

@Composable fun LanguageScreen(onSelect:(AppLanguage)->Unit){Column(Modifier.fillMaxSize().background(dark).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(55.dp));Text("NAG PENSÉE",color=gold,style=MaterialTheme.typography.headlineMedium);Text("Une pensée, une trace",color=muted);Spacer(Modifier.height(40.dp));Text("Choisis ta langue",color=ink,style=MaterialTheme.typography.headlineSmall);Text("Choose your language",color=muted);Spacer(Modifier.height(20.dp));AppLanguage.values().forEach{l->Button(onClick={onSelect(l)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),colors=ButtonDefaults.buttonColors(containerColor=panel,contentColor=ink)){Column(Modifier.fillMaxWidth()){Text(l.nativeName);Text(l.countryHint,color=muted,style=MaterialTheme.typography.labelSmall)}}};Spacer(Modifier.height(14.dp));Text("Tu pourras modifier ce choix dans les paramètres.",color=muted,style=MaterialTheme.typography.labelSmall)}}

@Composable fun Home(list:List<Thought>,l:AppLanguage,onNew:()->Unit,onOpen:(Thought)->Unit){val x=labels[l.code]!!;LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("NAG PENSÉE",color=gold,style=MaterialTheme.typography.titleLarge);Text("Que penses-tu aujourd’hui ?",color=ink,style=MaterialTheme.typography.headlineSmall);Text("— Guero",color=gold,style=MaterialTheme.typography.labelSmall)};item{Button(onClick=onNew,colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark),modifier=Modifier.fillMaxWidth()){Text("+  ${x["new"]}")}};item{Text(x["categories"]!!.uppercase(),color=muted,style=MaterialTheme.typography.labelMedium)};item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){cats.take(6).forEach{c->Column(Modifier.width(118.dp)){Illustration(Modifier.height(92.dp));Text(c,color=ink,style=MaterialTheme.typography.labelMedium);Text("${list.count{it.category==c}}",color=muted)}}}};item{Text(x["recent"]!!.uppercase(),color=muted,style=MaterialTheme.typography.labelMedium)};items(list.sortedByDescending{it.timestamp}.take(6)){ThoughtCard(it,onOpen,l)}}}
@Composable fun ThoughtCard(t:Thought,onOpen:(Thought)->Unit,l:AppLanguage){Card(Modifier.fillMaxWidth().clickable{onOpen(t)},colors=CardDefaults.cardColors(containerColor=panel)){Column{Illustration(Modifier.fillMaxWidth().height(145.dp));Column(Modifier.padding(14.dp)){Text(t.category,color=gold,style=MaterialTheme.typography.labelSmall);Text("“${t.text}”",color=ink);if(t.tags.isNotBlank())Text("#${t.tags}",color=muted,style=MaterialTheme.typography.labelSmall)}}}}
@Composable fun Favorites(list:List<Thought>,l:AppLanguage,onOpen:(Thought)->Unit){
    val fav=list.filter{it.favorite}
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("Favoris",color=ink,style=MaterialTheme.typography.headlineMedium);Text("Tes pensées marquées comme importantes.",color=muted)}
        if(fav.isEmpty()) item{Text("Aucun favori pour le moment.",color=muted,modifier=Modifier.padding(vertical=24.dp))}
        items(fav){ThoughtCard(it,onOpen,l)}
    }
}

@Composable fun Categories(list:List<Thought>,l:AppLanguage,onOpen:(Thought)->Unit){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(labels[l.code]!!["categories"]!!,color=ink,style=MaterialTheme.typography.headlineMedium)};items(cats){c->val t=list.firstOrNull{it.category==c};Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(16.dp)).padding(8.dp)){Illustration(Modifier.size(120.dp,80.dp));Column(Modifier.padding(8.dp)){Text(c,color=ink);Text("${list.count{it.category==c}}",color=muted);if(t!=null)Text(t.text.take(70),color=muted,style=MaterialTheme.typography.bodySmall)}}}}}
@Composable fun Search(list:List<Thought>,l:AppLanguage,onOpen:(Thought)->Unit){var q by remember{mutableStateOf("")};val v=list.filter{q.isBlank()||it.text.contains(q,true)||it.tags.contains(q,true)||it.category.contains(q,true)};Column(Modifier.padding(16.dp)){OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text(labels[l.code]!!["search"]!!)});Spacer(Modifier.height(10.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(v){ThoughtCard(it,onOpen,l)}}}}
@Composable fun Detail(t:Thought,l:AppLanguage,onBack:()->Unit,onEdit:()->Unit,onDelete:()->Unit,onFavorite:()->Unit,onShare:()->Unit){AlertDialog(onDismissRequest=onBack,containerColor=panel,title={Text(t.category,color=gold)},text={Column{Illustration(Modifier.fillMaxWidth().height(150.dp));Spacer(Modifier.height(10.dp));Text(t.text,color=ink);Spacer(Modifier.height(12.dp));Button(onClick={OnlineVoiceService.enqueue(t.text,l.code)},colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark)){Text("▶  ${labels[l.code]!!["read"]}")};Text("Lecture en ligne uniquement",color=muted,style=MaterialTheme.typography.labelSmall);if(t.tags.isNotBlank())Text("#${t.tags}",color=muted);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick=onFavorite){Text(if(t.favorite) "★ Favori" else "☆ Ajouter aux favoris",color=gold)};TextButton(onClick=onShare){Text(if(t.shared) "Partagé" else "Partager",color=gold)}}}},confirmButton={Button(onClick=onEdit){Text("Modifier")}},dismissButton={TextButton(onClick=onDelete){Text("Supprimer")}})}
@Composable fun Profile(l:AppLanguage,secure:SecurePrefs,list:List<Thought>){
    var enabled by remember{mutableStateOf(secure.syncEnabled())}; var endpoint by remember{mutableStateOf(secure.syncEndpoint())}; var token by remember{mutableStateOf(secure.syncToken() ?: "")}; var status by remember{mutableStateOf("")}; val scope=rememberCoroutineScope()
    Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text(labels[l.code]!!["profile"]!!,color=ink,style=MaterialTheme.typography.headlineMedium); Text("— Guero",color=gold,style=MaterialTheme.typography.labelSmall); Illustration(Modifier.fillMaxWidth().height(160.dp))
        Text("🔒 Sécurité — PIN / biométrie",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("☁ Coffre cloud privé",color=gold,style=MaterialTheme.typography.titleMedium)
        Row(verticalAlignment=Alignment.CenterVertically){Text("Activer la synchronisation",color=ink,modifier=Modifier.weight(1f));Switch(checked=enabled,onCheckedChange={enabled=it;secure.setSyncEnabled(it)})}
        OutlinedTextField(endpoint,{endpoint=it},Modifier.fillMaxWidth(),label={Text("Adresse du serveur")})
        OutlinedTextField(token,{token=it;secure.setSyncToken(it)},Modifier.fillMaxWidth(),label={Text("Jeton d'accès")},singleLine=true)
        Button(onClick={scope.launch{status="Synchronisation…";status=PrivateSyncService.sync(list,secure).message}},enabled=enabled,colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark),modifier=Modifier.fillMaxWidth()){Text("☁ Synchroniser maintenant")}
        if(secure.lastSync()>0)Text("Dernière synchronisation : "+java.text.DateFormat.getDateTimeInstance().format(java.util.Date(secure.lastSync())),color=muted,style=MaterialTheme.typography.labelSmall)
        if(status.isNotBlank())Text(status,color=ink)
        Text("🔊 Lecture à haute voix — en ligne uniquement",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("✦ IA — optionnelle et soumise à consentement",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("L’IA pourra résumer, classer ou relier des pensées uniquement après ton accord et après affichage des données envoyées.",color=muted,style=MaterialTheme.typography.bodySmall)
        Text("◉ Compte NAG",color=gold,style=MaterialTheme.typography.titleMedium)
        Text("Compte privé • récupération sécurisée • aucun profil public par défaut",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("▣ Appareils autorisés",color=gold,style=MaterialTheme.typography.titleMedium)
        Text("Cet appareil • synchronisation chiffrée • révocation possible depuis le compte",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("↗ Partage contrôlé",color=gold,style=MaterialTheme.typography.titleMedium)
        Text("Une pensée peut être partagée volontairement. Le partage est explicite et n’ouvre pas l’archive complète.",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
        Text("◐ Langue — ${l.nativeName}",color=ink,modifier=Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(16.dp))
    }
}

@Composable fun Editor(t:Thought?,l:AppLanguage,onDismiss:()->Unit,onSave:(String,String,String)->Unit){var text by remember{mutableStateOf(t?.text?:"")};var cat by remember{mutableStateOf(t?.category?:cats[0])};var tags by remember{mutableStateOf(t?.tags?:"")};AlertDialog(onDismissRequest=onDismiss,containerColor=panel,title={Text(labels[l.code]!!["new"]!!,color=ink)},text={Column{Illustration(Modifier.fillMaxWidth().height(110.dp));OutlinedTextField(text,{text=it},Modifier.fillMaxWidth().heightIn(min=120.dp),label={Text("…")});Spacer(Modifier.height(8.dp));OutlinedTextField(cat,{cat=it},Modifier.fillMaxWidth(),label={Text("Catégorie")});Spacer(Modifier.height(8.dp));OutlinedTextField(tags,{tags=it},Modifier.fillMaxWidth(),label={Text("Mots-clés")})}},confirmButton={Button(onClick={if(text.isNotBlank())onSave(text.trim(),cat,tags.trim())},colors=ButtonDefaults.buttonColors(containerColor=gold,contentColor=dark)){Text(labels[l.code]!!["save"]!!)}},dismissButton={TextButton(onClick=onDismiss){Text(labels[l.code]!!["cancel"]!!)}})}

private val darkScheme=darkColorScheme(primary=gold,background=dark,surface=panel,onBackground=ink,onSurface=ink)
object OnlineVoiceService { fun enqueue(text:String,languageCode:String){ /* Cloud TTS endpoint reserved: POST /v1/tts */ } }
